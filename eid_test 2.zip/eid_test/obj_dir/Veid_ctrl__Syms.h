// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VEID_CTRL__SYMS_H_
#define VERILATED_VEID_CTRL__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Veid_ctrl.h"

// INCLUDE MODULE CLASSES
#include "Veid_ctrl___024root.h"
#include "Veid_ctrl___024unit.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Veid_ctrl__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Veid_ctrl* const __Vm_modelp;
    bool __Vm_activity = false;  ///< Used by trace routines to determine change occurred
    uint32_t __Vm_baseCode = 0;  ///< Used by trace routines when tracing multiple models
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Veid_ctrl___024root            TOP;

    // COVERAGE
    uint32_t __Vcoverage[487];

    // CONSTRUCTORS
    Veid_ctrl__Syms(VerilatedContext* contextp, const char* namep, Veid_ctrl* modelp);
    ~Veid_ctrl__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
