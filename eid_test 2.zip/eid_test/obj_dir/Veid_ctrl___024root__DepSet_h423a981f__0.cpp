// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Veid_ctrl.h for the primary calling header

#include "Veid_ctrl__pch.h"
#include "Veid_ctrl___024root.h"

void Veid_ctrl___024root___ico_sequent__TOP__0(Veid_ctrl___024root* vlSelf);

void Veid_ctrl___024root___eval_ico(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_ico\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        Veid_ctrl___024root___ico_sequent__TOP__0(vlSelf);
    }
}

void Veid_ctrl___024root___eval_triggers__ico(Veid_ctrl___024root* vlSelf);

bool Veid_ctrl___024root___eval_phase__ico(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_phase__ico\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VicoExecute;
    // Body
    Veid_ctrl___024root___eval_triggers__ico(vlSelf);
    __VicoExecute = vlSelfRef.__VicoTriggered.any();
    if (__VicoExecute) {
        Veid_ctrl___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void Veid_ctrl___024root___eval_act(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_act\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Veid_ctrl___024root___nba_sequent__TOP__0(Veid_ctrl___024root* vlSelf);
void Veid_ctrl___024root___nba_sequent__TOP__1(Veid_ctrl___024root* vlSelf);

void Veid_ctrl___024root___eval_nba(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_nba\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Veid_ctrl___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[1U] = 1U;
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Veid_ctrl___024root___nba_sequent__TOP__1(vlSelf);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
    }
}

void Veid_ctrl___024root___eval_triggers__act(Veid_ctrl___024root* vlSelf);

bool Veid_ctrl___024root___eval_phase__act(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_phase__act\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Veid_ctrl___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Veid_ctrl___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Veid_ctrl___024root___eval_phase__nba(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_phase__nba\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Veid_ctrl___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__ico(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__nba(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__act(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG

void Veid_ctrl___024root___eval(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VicoIterCount;
    CData/*0:0*/ __VicoContinue;
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VicoIterCount = 0U;
    vlSelfRef.__VicoFirstIteration = 1U;
    __VicoContinue = 1U;
    while (__VicoContinue) {
        if (VL_UNLIKELY(((0x64U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Veid_ctrl___024root___dump_triggers__ico(vlSelf);
#endif
            VL_FATAL_MT("eid_ctrl.v", 8, "", "Input combinational region did not converge.");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        __VicoContinue = 0U;
        if (Veid_ctrl___024root___eval_phase__ico(vlSelf)) {
            __VicoContinue = 1U;
        }
        vlSelfRef.__VicoFirstIteration = 0U;
    }
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Veid_ctrl___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("eid_ctrl.v", 8, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Veid_ctrl___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("eid_ctrl.v", 8, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Veid_ctrl___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Veid_ctrl___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Veid_ctrl___024root___eval_debug_assertions(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_debug_assertions\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.clk & 0xfeU)))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY(((vlSelfRef.rst_n & 0xfeU)))) {
        Verilated::overWidthError("rst_n");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_awaddr & 0xf0U)))) {
        Verilated::overWidthError("s_axi_awaddr");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_awvalid & 0xfeU)))) {
        Verilated::overWidthError("s_axi_awvalid");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_wvalid & 0xfeU)))) {
        Verilated::overWidthError("s_axi_wvalid");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_araddr & 0xf0U)))) {
        Verilated::overWidthError("s_axi_araddr");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_arvalid & 0xfeU)))) {
        Verilated::overWidthError("s_axi_arvalid");}
    if (VL_UNLIKELY(((vlSelfRef.s_axi_rready & 0xfeU)))) {
        Verilated::overWidthError("s_axi_rready");}
    if (VL_UNLIKELY(((vlSelfRef.din_valid & 0xfeU)))) {
        Verilated::overWidthError("din_valid");}
    if (VL_UNLIKELY(((vlSelfRef.dout_ready & 0xfeU)))) {
        Verilated::overWidthError("dout_ready");}
}
#endif  // VL_DEBUG
