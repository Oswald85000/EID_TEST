// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Veid_ctrl.h for the primary calling header

#include "Veid_ctrl__pch.h"
#include "Veid_ctrl__Syms.h"
#include "Veid_ctrl___024root.h"

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__ico(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG

void Veid_ctrl___024root___eval_triggers__ico(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_triggers__ico\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VicoTriggered.setBit(0U, (IData)(vlSelfRef.__VicoFirstIteration));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Veid_ctrl___024root___dump_triggers__ico(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Veid_ctrl___024root___ico_sequent__TOP__0(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___ico_sequent__TOP__0\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.clk) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__clk))) {
        ++(vlSymsp->__Vcoverage[0]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__clk = vlSelfRef.clk;
    }
    if (((IData)(vlSelfRef.rst_n) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__rst_n))) {
        ++(vlSymsp->__Vcoverage[1]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__rst_n = vlSelfRef.rst_n;
    }
    if (((IData)(vlSelfRef.s_axi_awvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awvalid))) {
        ++(vlSymsp->__Vcoverage[6]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awvalid 
            = vlSelfRef.s_axi_awvalid;
    }
    if (((IData)(vlSelfRef.s_axi_wvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wvalid))) {
        ++(vlSymsp->__Vcoverage[40]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wvalid 
            = vlSelfRef.s_axi_wvalid;
    }
    if (((IData)(vlSelfRef.s_axi_arvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_arvalid))) {
        ++(vlSymsp->__Vcoverage[45]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_arvalid 
            = vlSelfRef.s_axi_arvalid;
    }
    if (((IData)(vlSelfRef.s_axi_rready) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rready))) {
        ++(vlSymsp->__Vcoverage[47]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rready 
            = vlSelfRef.s_axi_rready;
    }
    if (((IData)(vlSelfRef.din_valid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__din_valid))) {
        ++(vlSymsp->__Vcoverage[144]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_valid 
            = vlSelfRef.din_valid;
    }
    if (((IData)(vlSelfRef.dout_ready) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_ready))) {
        ++(vlSymsp->__Vcoverage[179]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_ready 
            = vlSelfRef.dout_ready;
    }
    if ((1U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[2]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xeU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (1U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((2U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[3]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xdU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (2U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((4U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[4]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xbU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (4U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((8U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[5]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((7U & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (8U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((1U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[41]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xeU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (1U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((2U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[42]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xdU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (2U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((4U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[43]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xbU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (4U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((8U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[44]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((7U & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (8U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    vlSelfRef.dout_valid = ((IData)(vlSelfRef.dout_ready) 
                            & (IData)(vlSelfRef.eid_ctrl__DOT__v2));
    if ((1U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[8]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (1U & vlSelfRef.s_axi_wdata));
    }
    if ((2U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[9]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (2U & vlSelfRef.s_axi_wdata));
    }
    if ((4U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[10]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (4U & vlSelfRef.s_axi_wdata));
    }
    if ((8U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[11]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (8U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[12]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[13]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[14]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40U & vlSelfRef.s_axi_wdata));
    }
    if ((0x80U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[15]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80U & vlSelfRef.s_axi_wdata));
    }
    if ((0x100U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[16]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x100U & vlSelfRef.s_axi_wdata));
    }
    if ((0x200U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[17]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x200U & vlSelfRef.s_axi_wdata));
    }
    if ((0x400U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[18]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x400U & vlSelfRef.s_axi_wdata));
    }
    if ((0x800U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[19]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x800U & vlSelfRef.s_axi_wdata));
    }
    if ((0x1000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[20]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x1000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x2000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[21]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x2000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x4000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[22]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x4000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x8000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[23]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x8000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[24]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[25]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[26]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x80000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[27]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x100000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[28]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x100000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x200000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[29]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x200000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x400000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[30]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x400000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x800000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[31]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x800000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x1000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[32]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x1000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x2000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[33]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x2000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x4000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[34]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x4000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x8000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[35]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x8000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[36]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[37]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[38]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40000000U & vlSelfRef.s_axi_wdata));
    }
    if (((vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[39]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80000000U & vlSelfRef.s_axi_wdata));
    }
    if ((1U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[48]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (1U & vlSelfRef.din_h));
    }
    if ((2U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[49]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (2U & vlSelfRef.din_h));
    }
    if ((4U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[50]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (4U & vlSelfRef.din_h));
    }
    if ((8U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[51]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (8U & vlSelfRef.din_h));
    }
    if ((0x10U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[52]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10U & vlSelfRef.din_h));
    }
    if ((0x20U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[53]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20U & vlSelfRef.din_h));
    }
    if ((0x40U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[54]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40U & vlSelfRef.din_h));
    }
    if ((0x80U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[55]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80U & vlSelfRef.din_h));
    }
    if ((0x100U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[56]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x100U & vlSelfRef.din_h));
    }
    if ((0x200U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[57]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x200U & vlSelfRef.din_h));
    }
    if ((0x400U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[58]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x400U & vlSelfRef.din_h));
    }
    if ((0x800U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[59]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x800U & vlSelfRef.din_h));
    }
    if ((0x1000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[60]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x1000U & vlSelfRef.din_h));
    }
    if ((0x2000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[61]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x2000U & vlSelfRef.din_h));
    }
    if ((0x4000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[62]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x4000U & vlSelfRef.din_h));
    }
    if ((0x8000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[63]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x8000U & vlSelfRef.din_h));
    }
    if ((0x10000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[64]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10000U & vlSelfRef.din_h));
    }
    if ((0x20000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[65]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20000U & vlSelfRef.din_h));
    }
    if ((0x40000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[66]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40000U & vlSelfRef.din_h));
    }
    if ((0x80000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[67]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80000U & vlSelfRef.din_h));
    }
    if ((0x100000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[68]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x100000U & vlSelfRef.din_h));
    }
    if ((0x200000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[69]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x200000U & vlSelfRef.din_h));
    }
    if ((0x400000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[70]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x400000U & vlSelfRef.din_h));
    }
    if ((0x800000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[71]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x800000U & vlSelfRef.din_h));
    }
    if ((0x1000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[72]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x1000000U & vlSelfRef.din_h));
    }
    if ((0x2000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[73]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x2000000U & vlSelfRef.din_h));
    }
    if ((0x4000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[74]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x4000000U & vlSelfRef.din_h));
    }
    if ((0x8000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[75]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x8000000U & vlSelfRef.din_h));
    }
    if ((0x10000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[76]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10000000U & vlSelfRef.din_h));
    }
    if ((0x20000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[77]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20000000U & vlSelfRef.din_h));
    }
    if ((0x40000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[78]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40000000U & vlSelfRef.din_h));
    }
    if (((vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[79]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80000000U & vlSelfRef.din_h));
    }
    if ((1U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[80]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (1U & vlSelfRef.din_f));
    }
    if ((2U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[81]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (2U & vlSelfRef.din_f));
    }
    if ((4U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[82]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (4U & vlSelfRef.din_f));
    }
    if ((8U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[83]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (8U & vlSelfRef.din_f));
    }
    if ((0x10U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[84]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10U & vlSelfRef.din_f));
    }
    if ((0x20U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[85]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20U & vlSelfRef.din_f));
    }
    if ((0x40U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[86]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40U & vlSelfRef.din_f));
    }
    if ((0x80U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[87]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80U & vlSelfRef.din_f));
    }
    if ((0x100U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[88]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x100U & vlSelfRef.din_f));
    }
    if ((0x200U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[89]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x200U & vlSelfRef.din_f));
    }
    if ((0x400U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[90]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x400U & vlSelfRef.din_f));
    }
    if ((0x800U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[91]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x800U & vlSelfRef.din_f));
    }
    if ((0x1000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[92]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x1000U & vlSelfRef.din_f));
    }
    if ((0x2000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[93]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x2000U & vlSelfRef.din_f));
    }
    if ((0x4000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[94]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x4000U & vlSelfRef.din_f));
    }
    if ((0x8000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[95]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x8000U & vlSelfRef.din_f));
    }
    if ((0x10000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[96]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10000U & vlSelfRef.din_f));
    }
    if ((0x20000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[97]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20000U & vlSelfRef.din_f));
    }
    if ((0x40000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[98]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40000U & vlSelfRef.din_f));
    }
    if ((0x80000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[99]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80000U & vlSelfRef.din_f));
    }
    if ((0x100000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[100]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x100000U & vlSelfRef.din_f));
    }
    if ((0x200000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[101]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x200000U & vlSelfRef.din_f));
    }
    if ((0x400000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[102]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x400000U & vlSelfRef.din_f));
    }
    if ((0x800000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[103]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x800000U & vlSelfRef.din_f));
    }
    if ((0x1000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[104]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x1000000U & vlSelfRef.din_f));
    }
    if ((0x2000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[105]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x2000000U & vlSelfRef.din_f));
    }
    if ((0x4000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[106]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x4000000U & vlSelfRef.din_f));
    }
    if ((0x8000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[107]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x8000000U & vlSelfRef.din_f));
    }
    if ((0x10000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[108]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10000000U & vlSelfRef.din_f));
    }
    if ((0x20000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[109]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20000000U & vlSelfRef.din_f));
    }
    if ((0x40000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[110]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40000000U & vlSelfRef.din_f));
    }
    if (((vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[111]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80000000U & vlSelfRef.din_f));
    }
    if ((1U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[112]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (1U & vlSelfRef.din_o));
    }
    if ((2U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[113]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (2U & vlSelfRef.din_o));
    }
    if ((4U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[114]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (4U & vlSelfRef.din_o));
    }
    if ((8U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[115]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (8U & vlSelfRef.din_o));
    }
    if ((0x10U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[116]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10U & vlSelfRef.din_o));
    }
    if ((0x20U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[117]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20U & vlSelfRef.din_o));
    }
    if ((0x40U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[118]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40U & vlSelfRef.din_o));
    }
    if ((0x80U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[119]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80U & vlSelfRef.din_o));
    }
    if ((0x100U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[120]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x100U & vlSelfRef.din_o));
    }
    if ((0x200U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[121]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x200U & vlSelfRef.din_o));
    }
    if ((0x400U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[122]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x400U & vlSelfRef.din_o));
    }
    if ((0x800U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[123]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x800U & vlSelfRef.din_o));
    }
    if ((0x1000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[124]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x1000U & vlSelfRef.din_o));
    }
    if ((0x2000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[125]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x2000U & vlSelfRef.din_o));
    }
    if ((0x4000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[126]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x4000U & vlSelfRef.din_o));
    }
    if ((0x8000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[127]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x8000U & vlSelfRef.din_o));
    }
    if ((0x10000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[128]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10000U & vlSelfRef.din_o));
    }
    if ((0x20000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[129]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20000U & vlSelfRef.din_o));
    }
    if ((0x40000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[130]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40000U & vlSelfRef.din_o));
    }
    if ((0x80000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[131]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80000U & vlSelfRef.din_o));
    }
    if ((0x100000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[132]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x100000U & vlSelfRef.din_o));
    }
    if ((0x200000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[133]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x200000U & vlSelfRef.din_o));
    }
    if ((0x400000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[134]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x400000U & vlSelfRef.din_o));
    }
    if ((0x800000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[135]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x800000U & vlSelfRef.din_o));
    }
    if ((0x1000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[136]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x1000000U & vlSelfRef.din_o));
    }
    if ((0x2000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[137]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x2000000U & vlSelfRef.din_o));
    }
    if ((0x4000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[138]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x4000000U & vlSelfRef.din_o));
    }
    if ((0x8000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[139]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x8000000U & vlSelfRef.din_o));
    }
    if ((0x10000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[140]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10000000U & vlSelfRef.din_o));
    }
    if ((0x20000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[141]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20000000U & vlSelfRef.din_o));
    }
    if ((0x40000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[142]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40000000U & vlSelfRef.din_o));
    }
    if (((vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[143]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80000000U & vlSelfRef.din_o));
    }
    vlSelfRef.eid_ctrl__DOT__m_alpha = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                        >> 0x10U))));
    vlSelfRef.eid_ctrl__DOT__m_beta = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                           (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                            >> 0x10U)))
                                        ? 0x7fffffffU
                                        : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                               (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                                >> 0x10U)))
                                            ? 0x80000000U
                                            : (IData)(
                                                      (VL_MULS_QQQ(64, 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                       >> 0x10U))));
    vlSelfRef.eid_ctrl__DOT__m_gamma = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                        >> 0x10U))));
    if (((IData)(vlSelfRef.dout_valid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid))) {
        ++(vlSymsp->__Vcoverage[178]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid 
            = vlSelfRef.dout_valid;
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[321]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[322]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[323]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[324]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[325]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[326]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[327]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[328]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[329]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[330]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[331]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[332]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[333]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[334]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[335]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[336]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[337]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[338]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[339]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[340]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[341]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[342]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[343]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[344]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[345]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[346]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[347]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[348]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[349]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[350]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[351]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[352]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[353]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[354]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[355]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[356]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[357]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[358]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[359]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[360]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[361]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[362]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[363]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[364]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[365]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[366]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[367]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[368]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[369]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[370]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[371]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[372]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[373]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[374]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[375]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[376]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[377]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[378]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[379]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[380]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[381]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[382]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[383]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[384]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[385]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[386]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[387]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[388]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[389]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[390]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[391]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[392]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[393]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[394]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[395]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[396]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[397]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[398]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[399]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[400]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[401]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[402]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[403]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[404]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[405]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[406]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[407]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[408]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[409]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[410]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[411]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[412]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[413]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[414]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[415]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[416]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__act(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG

void Veid_ctrl___024root___eval_triggers__act(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_triggers__act\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered.setBit(0U, ((IData)(vlSelfRef.clk) 
                                          & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__clk__0))));
    vlSelfRef.__VactTriggered.setBit(1U, ((~ (IData)(vlSelfRef.rst_n)) 
                                          & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__rst_n__0)));
    vlSelfRef.__Vtrigprevexpr___TOP__clk__0 = vlSelfRef.clk;
    vlSelfRef.__Vtrigprevexpr___TOP__rst_n__0 = vlSelfRef.rst_n;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Veid_ctrl___024root___dump_triggers__act(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Veid_ctrl___024root___nba_sequent__TOP__0(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___nba_sequent__TOP__0\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    ++(vlSymsp->__Vcoverage[484]);
    ++(vlSymsp->__Vcoverage[486]);
    vlSelfRef.eid_ctrl__DOT__v2 = vlSelfRef.eid_ctrl__DOT__v1;
    vlSelfRef.eid_ctrl__DOT__alarm_r = VL_LTS_III(32, vlSelfRef.eid_ctrl__DOT__alpha, vlSelfRef.eid_ctrl__DOT__beta);
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v2) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v2))) {
        ++(vlSymsp->__Vcoverage[483]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v2 = vlSelfRef.eid_ctrl__DOT__v2;
    }
    vlSelfRef.dout_valid = ((IData)(vlSelfRef.dout_ready) 
                            & (IData)(vlSelfRef.eid_ctrl__DOT__v2));
    vlSelfRef.eid_ctrl__DOT__v1 = vlSelfRef.eid_ctrl__DOT__v0;
    if (((IData)(vlSelfRef.eid_ctrl__DOT__alarm_r) 
         ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__alarm_r))) {
        ++(vlSymsp->__Vcoverage[485]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alarm_r 
            = vlSelfRef.eid_ctrl__DOT__alarm_r;
    }
    vlSelfRef.dout_alarm = vlSelfRef.eid_ctrl__DOT__alarm_r;
    if (((IData)(vlSelfRef.dout_valid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid))) {
        ++(vlSymsp->__Vcoverage[178]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid 
            = vlSelfRef.dout_valid;
    }
    if (((IData)(vlSelfRef.dout_alarm) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_alarm))) {
        ++(vlSymsp->__Vcoverage[177]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_alarm 
            = vlSelfRef.dout_alarm;
    }
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v1) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v1))) {
        ++(vlSymsp->__Vcoverage[482]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v1 = vlSelfRef.eid_ctrl__DOT__v1;
    }
    vlSelfRef.eid_ctrl__DOT__v0 = vlSelfRef.din_valid;
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v0) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v0))) {
        ++(vlSymsp->__Vcoverage[481]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v0 = vlSelfRef.eid_ctrl__DOT__v0;
    }
}

VL_INLINE_OPT void Veid_ctrl___024root___nba_sequent__TOP__1(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___nba_sequent__TOP__1\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.rst_n) {
        if (((IData)(vlSelfRef.s_axi_awvalid) & (IData)(vlSelfRef.s_axi_wvalid))) {
            if ((8U & (IData)(vlSelfRef.s_axi_awaddr))) {
                if ((4U & (IData)(vlSelfRef.s_axi_awaddr))) {
                    ++(vlSymsp->__Vcoverage[311]);
                    vlSelfRef.eid_ctrl__DOT__delta 
                        = vlSelfRef.s_axi_wdata;
                } else {
                    ++(vlSymsp->__Vcoverage[310]);
                    vlSelfRef.eid_ctrl__DOT__gamma 
                        = vlSelfRef.s_axi_wdata;
                }
            } else if ((4U & (IData)(vlSelfRef.s_axi_awaddr))) {
                ++(vlSymsp->__Vcoverage[309]);
                vlSelfRef.eid_ctrl__DOT__beta = vlSelfRef.s_axi_wdata;
            } else {
                ++(vlSymsp->__Vcoverage[308]);
                vlSelfRef.eid_ctrl__DOT__alpha = vlSelfRef.s_axi_wdata;
            }
            ++(vlSymsp->__Vcoverage[312]);
        } else {
            ++(vlSymsp->__Vcoverage[313]);
        }
        if (((IData)(vlSelfRef.s_axi_awvalid) & (IData)(vlSelfRef.s_axi_wvalid))) {
            ++(vlSymsp->__Vcoverage[314]);
        }
        if ((1U & (~ (IData)(vlSelfRef.s_axi_wvalid)))) {
            ++(vlSymsp->__Vcoverage[315]);
        }
        if ((1U & (~ (IData)(vlSelfRef.s_axi_awvalid)))) {
            ++(vlSymsp->__Vcoverage[316]);
        }
    } else {
        ++(vlSymsp->__Vcoverage[317]);
        vlSelfRef.eid_ctrl__DOT__alpha = 0x13334U;
        vlSelfRef.eid_ctrl__DOT__beta = 0x10000U;
        vlSelfRef.eid_ctrl__DOT__gamma = 0xccdU;
        vlSelfRef.eid_ctrl__DOT__delta = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.rst_n)))) {
        ++(vlSymsp->__Vcoverage[318]);
    }
    if (vlSelfRef.rst_n) {
        ++(vlSymsp->__Vcoverage[319]);
    }
    ++(vlSymsp->__Vcoverage[320]);
    if ((1U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[276]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (1U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[277]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (2U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[278]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (4U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[279]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (8U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[280]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[281]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[282]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[283]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[284]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[285]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[286]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[287]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[288]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[289]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[290]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[291]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[292]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[293]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[294]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[295]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[296]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[297]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[298]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[299]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[300]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[301]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[302]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[303]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[304]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[305]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[306]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[307]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[244]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (1U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[245]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (2U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[246]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (4U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[247]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (8U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[248]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[249]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[250]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[251]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[252]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[253]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[254]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[255]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[256]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[257]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[258]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[259]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[260]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[261]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[262]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[263]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[264]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[265]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[266]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[267]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[268]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[269]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[270]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[271]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[272]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[273]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[274]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if (((vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[275]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    vlSelfRef.eid_ctrl__DOT__m_gamma = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                        >> 0x10U))));
    if ((1U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[212]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (1U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[213]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (2U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[214]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (4U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[215]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (8U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[216]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[217]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[218]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[219]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[220]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[221]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[222]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[223]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[224]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[225]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[226]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[227]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[228]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[229]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[230]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[231]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[232]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[233]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[234]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[235]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[236]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[237]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[238]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[239]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[240]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[241]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[242]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[243]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    vlSelfRef.eid_ctrl__DOT__m_beta = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                           (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                            >> 0x10U)))
                                        ? 0x7fffffffU
                                        : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                               (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                                >> 0x10U)))
                                            ? 0x80000000U
                                            : (IData)(
                                                      (VL_MULS_QQQ(64, 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                       >> 0x10U))));
    if ((1U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[180]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (1U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[181]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (2U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[182]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (4U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[183]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (8U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[184]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[185]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[186]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[187]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[188]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[189]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[190]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[191]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[192]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[193]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[194]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[195]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[196]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[197]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[198]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[199]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[200]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[201]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[202]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[203]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[204]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[205]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[206]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[207]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[208]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[209]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[210]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if (((vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[211]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    vlSelfRef.eid_ctrl__DOT__m_alpha = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                        >> 0x10U))));
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[385]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[386]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[387]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[388]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[389]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[390]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[391]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[392]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[393]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[394]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[395]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[396]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[397]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[398]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[399]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[400]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[401]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[402]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[403]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[404]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[405]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[406]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[407]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[408]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[409]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[410]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[411]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[412]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[413]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[414]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[415]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[416]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[353]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[354]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[355]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[356]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[357]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[358]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[359]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[360]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[361]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[362]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[363]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[364]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[365]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[366]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[367]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[368]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[369]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[370]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[371]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[372]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[373]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[374]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[375]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[376]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[377]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[378]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[379]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[380]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[381]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[382]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[383]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[384]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[321]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[322]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[323]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[324]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[325]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[326]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[327]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[328]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[329]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[330]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[331]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[332]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[333]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[334]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[335]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[336]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[337]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[338]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[339]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[340]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[341]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[342]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[343]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[344]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[345]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[346]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[347]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[348]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[349]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[350]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[351]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[352]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
}
