// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Veid_ctrl.h for the primary calling header

#ifndef VERILATED_VEID_CTRL___024UNIT_H_
#define VERILATED_VEID_CTRL___024UNIT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"


class Veid_ctrl__Syms;

class alignas(VL_CACHE_LINE_BYTES) Veid_ctrl___024unit final : public VerilatedModule {
  public:

    // INTERNAL VARIABLES
    Veid_ctrl__Syms* const vlSymsp;

    // CONSTRUCTORS
    Veid_ctrl___024unit(Veid_ctrl__Syms* symsp, const char* v__name);
    ~Veid_ctrl___024unit();
    VL_UNCOPYABLE(Veid_ctrl___024unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
};


#endif  // guard
