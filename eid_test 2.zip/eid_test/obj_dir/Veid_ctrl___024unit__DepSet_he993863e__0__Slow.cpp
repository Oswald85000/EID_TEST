// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Veid_ctrl.h for the primary calling header

#include "Veid_ctrl__pch.h"
#include "Veid_ctrl___024unit.h"

VL_ATTR_COLD void Veid_ctrl___024unit___ctor_var_reset(Veid_ctrl___024unit* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Veid_ctrl___024unit___ctor_var_reset\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Veid_ctrl___024unit___configure_coverage(Veid_ctrl___024unit* vlSelf, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Veid_ctrl___024unit___configure_coverage\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
}
