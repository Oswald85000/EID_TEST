// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Veid_ctrl.h for the primary calling header

#include "Veid_ctrl__pch.h"
#include "Veid_ctrl__Syms.h"
#include "Veid_ctrl___024root.h"

VL_ATTR_COLD void Veid_ctrl___024root___eval_initial__TOP(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_initial__TOP\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awready)))) {
        ++(vlSymsp->__Vcoverage[7]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awready = 1U;
    }
    if ((1U & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rdata)) {
        ++(vlSymsp->__Vcoverage[46]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rdata 
            = (0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rdata);
    }
    vlSelfRef.s_axi_awready = 1U;
    vlSelfRef.s_axi_wready = 1U;
    vlSelfRef.s_axi_arready = 1U;
    vlSelfRef.s_axi_rvalid = 0U;
    vlSelfRef.s_axi_rdata = 0U;
    vlSelfRef.din_ready = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__stl(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG

VL_ATTR_COLD void Veid_ctrl___024root___eval_triggers__stl(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_triggers__stl\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered.setBit(0U, (IData)(vlSelfRef.__VstlFirstIteration));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Veid_ctrl___024root___dump_triggers__stl(vlSelf);
    }
#endif
}

VL_ATTR_COLD void Veid_ctrl___024root___stl_sequent__TOP__0(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___stl_sequent__TOP__0\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.clk) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__clk))) {
        ++(vlSymsp->__Vcoverage[0]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__clk = vlSelfRef.clk;
    }
    if (((IData)(vlSelfRef.rst_n) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__rst_n))) {
        ++(vlSymsp->__Vcoverage[1]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__rst_n = vlSelfRef.rst_n;
    }
    if (((IData)(vlSelfRef.s_axi_awvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awvalid))) {
        ++(vlSymsp->__Vcoverage[6]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awvalid 
            = vlSelfRef.s_axi_awvalid;
    }
    if (((IData)(vlSelfRef.s_axi_wvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wvalid))) {
        ++(vlSymsp->__Vcoverage[40]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wvalid 
            = vlSelfRef.s_axi_wvalid;
    }
    if (((IData)(vlSelfRef.s_axi_arvalid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_arvalid))) {
        ++(vlSymsp->__Vcoverage[45]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_arvalid 
            = vlSelfRef.s_axi_arvalid;
    }
    if (((IData)(vlSelfRef.s_axi_rready) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rready))) {
        ++(vlSymsp->__Vcoverage[47]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_rready 
            = vlSelfRef.s_axi_rready;
    }
    if (((IData)(vlSelfRef.din_valid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__din_valid))) {
        ++(vlSymsp->__Vcoverage[144]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_valid 
            = vlSelfRef.din_valid;
    }
    if (((IData)(vlSelfRef.dout_ready) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_ready))) {
        ++(vlSymsp->__Vcoverage[179]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_ready 
            = vlSelfRef.dout_ready;
    }
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v0) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v0))) {
        ++(vlSymsp->__Vcoverage[481]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v0 = vlSelfRef.eid_ctrl__DOT__v0;
    }
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v1) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v1))) {
        ++(vlSymsp->__Vcoverage[482]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v1 = vlSelfRef.eid_ctrl__DOT__v1;
    }
    if (((IData)(vlSelfRef.eid_ctrl__DOT__v2) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__v2))) {
        ++(vlSymsp->__Vcoverage[483]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__v2 = vlSelfRef.eid_ctrl__DOT__v2;
    }
    if (((IData)(vlSelfRef.eid_ctrl__DOT__alarm_r) 
         ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__alarm_r))) {
        ++(vlSymsp->__Vcoverage[485]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alarm_r 
            = vlSelfRef.eid_ctrl__DOT__alarm_r;
    }
    if ((1U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[2]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xeU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (1U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((2U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[3]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xdU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (2U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((4U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[4]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((0xbU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (4U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((8U & ((IData)(vlSelfRef.s_axi_awaddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)))) {
        ++(vlSymsp->__Vcoverage[5]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr 
            = ((7U & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_awaddr)) 
               | (8U & (IData)(vlSelfRef.s_axi_awaddr)));
    }
    if ((1U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[41]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xeU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (1U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((2U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[42]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xdU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (2U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((4U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[43]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((0xbU & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (4U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    if ((8U & ((IData)(vlSelfRef.s_axi_araddr) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)))) {
        ++(vlSymsp->__Vcoverage[44]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr 
            = ((7U & (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_araddr)) 
               | (8U & (IData)(vlSelfRef.s_axi_araddr)));
    }
    vlSelfRef.dout_alarm = vlSelfRef.eid_ctrl__DOT__alarm_r;
    vlSelfRef.dout_valid = ((IData)(vlSelfRef.dout_ready) 
                            & (IData)(vlSelfRef.eid_ctrl__DOT__v2));
    if ((1U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[8]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (1U & vlSelfRef.s_axi_wdata));
    }
    if ((2U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[9]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (2U & vlSelfRef.s_axi_wdata));
    }
    if ((4U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[10]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (4U & vlSelfRef.s_axi_wdata));
    }
    if ((8U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[11]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (8U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[12]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[13]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[14]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40U & vlSelfRef.s_axi_wdata));
    }
    if ((0x80U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[15]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80U & vlSelfRef.s_axi_wdata));
    }
    if ((0x100U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[16]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x100U & vlSelfRef.s_axi_wdata));
    }
    if ((0x200U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[17]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x200U & vlSelfRef.s_axi_wdata));
    }
    if ((0x400U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[18]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x400U & vlSelfRef.s_axi_wdata));
    }
    if ((0x800U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[19]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x800U & vlSelfRef.s_axi_wdata));
    }
    if ((0x1000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[20]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x1000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x2000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[21]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x2000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x4000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[22]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x4000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x8000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[23]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x8000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[24]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[25]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[26]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x80000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[27]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x100000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[28]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x100000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x200000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[29]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x200000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x400000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[30]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x400000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x800000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[31]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x800000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x1000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[32]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x1000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x2000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[33]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x2000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x4000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[34]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x4000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x8000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[35]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x8000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x10000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[36]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x10000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x20000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[37]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x20000000U & vlSelfRef.s_axi_wdata));
    }
    if ((0x40000000U & (vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata))) {
        ++(vlSymsp->__Vcoverage[38]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x40000000U & vlSelfRef.s_axi_wdata));
    }
    if (((vlSelfRef.s_axi_wdata ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[39]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__s_axi_wdata) 
               | (0x80000000U & vlSelfRef.s_axi_wdata));
    }
    if ((1U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[48]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (1U & vlSelfRef.din_h));
    }
    if ((2U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[49]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (2U & vlSelfRef.din_h));
    }
    if ((4U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[50]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (4U & vlSelfRef.din_h));
    }
    if ((8U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[51]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (8U & vlSelfRef.din_h));
    }
    if ((0x10U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[52]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10U & vlSelfRef.din_h));
    }
    if ((0x20U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[53]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20U & vlSelfRef.din_h));
    }
    if ((0x40U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[54]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40U & vlSelfRef.din_h));
    }
    if ((0x80U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[55]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80U & vlSelfRef.din_h));
    }
    if ((0x100U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[56]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x100U & vlSelfRef.din_h));
    }
    if ((0x200U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[57]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x200U & vlSelfRef.din_h));
    }
    if ((0x400U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[58]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x400U & vlSelfRef.din_h));
    }
    if ((0x800U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[59]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x800U & vlSelfRef.din_h));
    }
    if ((0x1000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[60]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x1000U & vlSelfRef.din_h));
    }
    if ((0x2000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[61]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x2000U & vlSelfRef.din_h));
    }
    if ((0x4000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[62]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x4000U & vlSelfRef.din_h));
    }
    if ((0x8000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[63]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x8000U & vlSelfRef.din_h));
    }
    if ((0x10000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[64]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10000U & vlSelfRef.din_h));
    }
    if ((0x20000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[65]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20000U & vlSelfRef.din_h));
    }
    if ((0x40000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[66]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40000U & vlSelfRef.din_h));
    }
    if ((0x80000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[67]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80000U & vlSelfRef.din_h));
    }
    if ((0x100000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[68]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x100000U & vlSelfRef.din_h));
    }
    if ((0x200000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[69]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x200000U & vlSelfRef.din_h));
    }
    if ((0x400000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[70]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x400000U & vlSelfRef.din_h));
    }
    if ((0x800000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[71]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x800000U & vlSelfRef.din_h));
    }
    if ((0x1000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[72]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x1000000U & vlSelfRef.din_h));
    }
    if ((0x2000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[73]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x2000000U & vlSelfRef.din_h));
    }
    if ((0x4000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[74]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x4000000U & vlSelfRef.din_h));
    }
    if ((0x8000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[75]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x8000000U & vlSelfRef.din_h));
    }
    if ((0x10000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[76]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x10000000U & vlSelfRef.din_h));
    }
    if ((0x20000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[77]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x20000000U & vlSelfRef.din_h));
    }
    if ((0x40000000U & (vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h))) {
        ++(vlSymsp->__Vcoverage[78]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x40000000U & vlSelfRef.din_h));
    }
    if (((vlSelfRef.din_h ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[79]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_h) 
             | (0x80000000U & vlSelfRef.din_h));
    }
    if ((1U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[80]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (1U & vlSelfRef.din_f));
    }
    if ((2U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[81]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (2U & vlSelfRef.din_f));
    }
    if ((4U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[82]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (4U & vlSelfRef.din_f));
    }
    if ((8U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[83]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (8U & vlSelfRef.din_f));
    }
    if ((0x10U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[84]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10U & vlSelfRef.din_f));
    }
    if ((0x20U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[85]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20U & vlSelfRef.din_f));
    }
    if ((0x40U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[86]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40U & vlSelfRef.din_f));
    }
    if ((0x80U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[87]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80U & vlSelfRef.din_f));
    }
    if ((0x100U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[88]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x100U & vlSelfRef.din_f));
    }
    if ((0x200U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[89]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x200U & vlSelfRef.din_f));
    }
    if ((0x400U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[90]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x400U & vlSelfRef.din_f));
    }
    if ((0x800U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[91]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x800U & vlSelfRef.din_f));
    }
    if ((0x1000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[92]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x1000U & vlSelfRef.din_f));
    }
    if ((0x2000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[93]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x2000U & vlSelfRef.din_f));
    }
    if ((0x4000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[94]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x4000U & vlSelfRef.din_f));
    }
    if ((0x8000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[95]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x8000U & vlSelfRef.din_f));
    }
    if ((0x10000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[96]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10000U & vlSelfRef.din_f));
    }
    if ((0x20000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[97]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20000U & vlSelfRef.din_f));
    }
    if ((0x40000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[98]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40000U & vlSelfRef.din_f));
    }
    if ((0x80000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[99]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80000U & vlSelfRef.din_f));
    }
    if ((0x100000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[100]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x100000U & vlSelfRef.din_f));
    }
    if ((0x200000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[101]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x200000U & vlSelfRef.din_f));
    }
    if ((0x400000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[102]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x400000U & vlSelfRef.din_f));
    }
    if ((0x800000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[103]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x800000U & vlSelfRef.din_f));
    }
    if ((0x1000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[104]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x1000000U & vlSelfRef.din_f));
    }
    if ((0x2000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[105]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x2000000U & vlSelfRef.din_f));
    }
    if ((0x4000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[106]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x4000000U & vlSelfRef.din_f));
    }
    if ((0x8000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[107]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x8000000U & vlSelfRef.din_f));
    }
    if ((0x10000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[108]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x10000000U & vlSelfRef.din_f));
    }
    if ((0x20000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[109]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x20000000U & vlSelfRef.din_f));
    }
    if ((0x40000000U & (vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f))) {
        ++(vlSymsp->__Vcoverage[110]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x40000000U & vlSelfRef.din_f));
    }
    if (((vlSelfRef.din_f ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[111]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_f) 
             | (0x80000000U & vlSelfRef.din_f));
    }
    if ((1U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[112]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (1U & vlSelfRef.din_o));
    }
    if ((2U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[113]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (2U & vlSelfRef.din_o));
    }
    if ((4U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[114]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (4U & vlSelfRef.din_o));
    }
    if ((8U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[115]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (8U & vlSelfRef.din_o));
    }
    if ((0x10U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[116]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10U & vlSelfRef.din_o));
    }
    if ((0x20U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[117]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20U & vlSelfRef.din_o));
    }
    if ((0x40U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[118]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40U & vlSelfRef.din_o));
    }
    if ((0x80U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[119]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80U & vlSelfRef.din_o));
    }
    if ((0x100U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[120]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x100U & vlSelfRef.din_o));
    }
    if ((0x200U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[121]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x200U & vlSelfRef.din_o));
    }
    if ((0x400U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[122]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x400U & vlSelfRef.din_o));
    }
    if ((0x800U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[123]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x800U & vlSelfRef.din_o));
    }
    if ((0x1000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[124]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x1000U & vlSelfRef.din_o));
    }
    if ((0x2000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[125]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x2000U & vlSelfRef.din_o));
    }
    if ((0x4000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[126]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x4000U & vlSelfRef.din_o));
    }
    if ((0x8000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[127]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x8000U & vlSelfRef.din_o));
    }
    if ((0x10000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[128]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10000U & vlSelfRef.din_o));
    }
    if ((0x20000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[129]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20000U & vlSelfRef.din_o));
    }
    if ((0x40000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[130]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40000U & vlSelfRef.din_o));
    }
    if ((0x80000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[131]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80000U & vlSelfRef.din_o));
    }
    if ((0x100000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[132]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x100000U & vlSelfRef.din_o));
    }
    if ((0x200000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[133]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x200000U & vlSelfRef.din_o));
    }
    if ((0x400000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[134]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x400000U & vlSelfRef.din_o));
    }
    if ((0x800000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[135]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x800000U & vlSelfRef.din_o));
    }
    if ((0x1000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[136]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x1000000U & vlSelfRef.din_o));
    }
    if ((0x2000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[137]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x2000000U & vlSelfRef.din_o));
    }
    if ((0x4000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[138]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x4000000U & vlSelfRef.din_o));
    }
    if ((0x8000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[139]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x8000000U & vlSelfRef.din_o));
    }
    if ((0x10000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[140]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x10000000U & vlSelfRef.din_o));
    }
    if ((0x20000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[141]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x20000000U & vlSelfRef.din_o));
    }
    if ((0x40000000U & (vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o))) {
        ++(vlSymsp->__Vcoverage[142]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x40000000U & vlSelfRef.din_o));
    }
    if (((vlSelfRef.din_o ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[143]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__din_o) 
             | (0x80000000U & vlSelfRef.din_o));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[180]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (1U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[181]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (2U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[182]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (4U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[183]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (8U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[184]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[185]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[186]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[187]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[188]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[189]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[190]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[191]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[192]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[193]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[194]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[195]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[196]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[197]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[198]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[199]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[200]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[201]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[202]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[203]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[204]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[205]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[206]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[207]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[208]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[209]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha))) {
        ++(vlSymsp->__Vcoverage[210]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if (((vlSelfRef.eid_ctrl__DOT__alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[211]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__alpha) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__alpha));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[212]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (1U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[213]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (2U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[214]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (4U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[215]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (8U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[216]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[217]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[218]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[219]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[220]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[221]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[222]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[223]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[224]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[225]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[226]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[227]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[228]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[229]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[230]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[231]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[232]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[233]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[234]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[235]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[236]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[237]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[238]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[239]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[240]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[241]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta))) {
        ++(vlSymsp->__Vcoverage[242]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[243]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__beta = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__beta) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__beta));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[244]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (1U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[245]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (2U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[246]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (4U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[247]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (8U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[248]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[249]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[250]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[251]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[252]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[253]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[254]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[255]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[256]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[257]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[258]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[259]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[260]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[261]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[262]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[263]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[264]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[265]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[266]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[267]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[268]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[269]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[270]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[271]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[272]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[273]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma))) {
        ++(vlSymsp->__Vcoverage[274]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if (((vlSelfRef.eid_ctrl__DOT__gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[275]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__gamma) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__gamma));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[276]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (1U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[277]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (2U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[278]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (4U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[279]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (8U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[280]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[281]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[282]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[283]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[284]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[285]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[286]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[287]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[288]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[289]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[290]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__delta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[291]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[292]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[293]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[294]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__delta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[295]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[296]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[297]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[298]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__delta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[299]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[300]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[301]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[302]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[303]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[304]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[305]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__delta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta))) {
        ++(vlSymsp->__Vcoverage[306]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__delta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[307]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__delta = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__delta) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__delta));
    }
    vlSelfRef.dout_dhdt = (VL_LTS_IQQ(33, 0x3fffffffULL, vlSelfRef.eid_ctrl__DOT__add_s2b__DOT__s)
                            ? 0x7fffffffU : (VL_GTS_IQQ(33, 0x1c0000000ULL, vlSelfRef.eid_ctrl__DOT__add_s2b__DOT__s)
                                              ? 0x80000000U
                                              : (IData)(vlSelfRef.eid_ctrl__DOT__add_s2b__DOT__s)));
    vlSelfRef.eid_ctrl__DOT__add1 = (VL_LTS_IQQ(33, 0x3fffffffULL, vlSelfRef.eid_ctrl__DOT__add_s1__DOT__s)
                                      ? 0x7fffffffU
                                      : (VL_GTS_IQQ(33, 0x1c0000000ULL, vlSelfRef.eid_ctrl__DOT__add_s1__DOT__s)
                                          ? 0x80000000U
                                          : (IData)(vlSelfRef.eid_ctrl__DOT__add_s1__DOT__s)));
    vlSelfRef.eid_ctrl__DOT__add2 = (VL_LTS_IQQ(33, 0x3fffffffULL, vlSelfRef.eid_ctrl__DOT__add_s2a__DOT__s)
                                      ? 0x7fffffffU
                                      : (VL_GTS_IQQ(33, 0x1c0000000ULL, vlSelfRef.eid_ctrl__DOT__add_s2a__DOT__s)
                                          ? 0x80000000U
                                          : (IData)(vlSelfRef.eid_ctrl__DOT__add_s2a__DOT__s)));
    vlSelfRef.eid_ctrl__DOT__m_alpha = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, 
                                                                                (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                                        >> 0x10U))));
    vlSelfRef.eid_ctrl__DOT__m_beta = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                           (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                            >> 0x10U)))
                                        ? 0x7fffffffU
                                        : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                               (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                                                >> 0x10U)))
                                            ? 0x80000000U
                                            : (IData)(
                                                      (VL_MULS_QQQ(64, 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                                   VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                                       >> 0x10U))));
    vlSelfRef.eid_ctrl__DOT__m_gamma = (VL_LTS_III(32, 0x7fffffffU, (IData)(
                                                                            (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                             >> 0x10U)))
                                         ? 0x7fffffffU
                                         : (VL_GTS_III(32, 0x80000000U, (IData)(
                                                                                (VL_MULS_QQQ(64, 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                                VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                                                >> 0x10U)))
                                             ? 0x80000000U
                                             : (IData)(
                                                       (VL_MULS_QQQ(64, 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                                    VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                                        >> 0x10U))));
    if (((IData)(vlSelfRef.dout_alarm) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_alarm))) {
        ++(vlSymsp->__Vcoverage[177]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_alarm 
            = vlSelfRef.dout_alarm;
    }
    if (((IData)(vlSelfRef.dout_valid) ^ (IData)(vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid))) {
        ++(vlSymsp->__Vcoverage[178]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_valid 
            = vlSelfRef.dout_valid;
    }
    if ((1U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[145]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (1U & vlSelfRef.dout_dhdt));
    }
    if ((2U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[146]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (2U & vlSelfRef.dout_dhdt));
    }
    if ((4U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[147]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (4U & vlSelfRef.dout_dhdt));
    }
    if ((8U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[148]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (8U & vlSelfRef.dout_dhdt));
    }
    if ((0x10U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[149]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x10U & vlSelfRef.dout_dhdt));
    }
    if ((0x20U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[150]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x20U & vlSelfRef.dout_dhdt));
    }
    if ((0x40U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[151]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x40U & vlSelfRef.dout_dhdt));
    }
    if ((0x80U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[152]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x80U & vlSelfRef.dout_dhdt));
    }
    if ((0x100U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[153]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x100U & vlSelfRef.dout_dhdt));
    }
    if ((0x200U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[154]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x200U & vlSelfRef.dout_dhdt));
    }
    if ((0x400U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[155]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x400U & vlSelfRef.dout_dhdt));
    }
    if ((0x800U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[156]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x800U & vlSelfRef.dout_dhdt));
    }
    if ((0x1000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[157]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x1000U & vlSelfRef.dout_dhdt));
    }
    if ((0x2000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[158]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x2000U & vlSelfRef.dout_dhdt));
    }
    if ((0x4000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[159]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x4000U & vlSelfRef.dout_dhdt));
    }
    if ((0x8000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[160]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x8000U & vlSelfRef.dout_dhdt));
    }
    if ((0x10000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[161]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x10000U & vlSelfRef.dout_dhdt));
    }
    if ((0x20000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[162]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x20000U & vlSelfRef.dout_dhdt));
    }
    if ((0x40000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[163]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x40000U & vlSelfRef.dout_dhdt));
    }
    if ((0x80000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[164]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x80000U & vlSelfRef.dout_dhdt));
    }
    if ((0x100000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[165]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x100000U & vlSelfRef.dout_dhdt));
    }
    if ((0x200000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[166]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x200000U & vlSelfRef.dout_dhdt));
    }
    if ((0x400000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[167]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x400000U & vlSelfRef.dout_dhdt));
    }
    if ((0x800000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[168]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x800000U & vlSelfRef.dout_dhdt));
    }
    if ((0x1000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[169]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x1000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x2000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[170]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x2000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x4000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[171]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x4000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x8000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[172]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x8000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x10000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[173]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x10000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x20000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[174]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x20000000U & vlSelfRef.dout_dhdt));
    }
    if ((0x40000000U & (vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt))) {
        ++(vlSymsp->__Vcoverage[175]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x40000000U & vlSelfRef.dout_dhdt));
    }
    if (((vlSelfRef.dout_dhdt ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[176]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__dout_dhdt) 
               | (0x80000000U & vlSelfRef.dout_dhdt));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[417]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (1U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[418]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (2U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[419]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (4U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[420]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (8U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[421]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[422]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[423]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[424]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[425]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[426]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[427]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[428]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[429]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[430]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[431]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[432]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__add1 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[433]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__add1 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[434]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__add1 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[435]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__add1 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[436]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__add1 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[437]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__add1 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[438]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__add1 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[439]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__add1 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[440]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[441]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[442]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[443]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[444]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[445]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[446]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__add1 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1))) {
        ++(vlSymsp->__Vcoverage[447]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if (((vlSelfRef.eid_ctrl__DOT__add1 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[448]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add1 = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add1) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__add1));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[449]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (1U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[450]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (2U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[451]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (4U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[452]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (8U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[453]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x10U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[454]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x20U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[455]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x40U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[456]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x80U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[457]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x100U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[458]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x200U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[459]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x400U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[460]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x800U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[461]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x1000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[462]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x2000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[463]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x4000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[464]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x8000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__add2 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[465]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x10000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__add2 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[466]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x20000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__add2 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[467]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x40000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__add2 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[468]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x80000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__add2 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[469]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x100000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__add2 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[470]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x200000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__add2 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[471]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x400000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__add2 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[472]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x800000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[473]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x1000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[474]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x2000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[475]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x4000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[476]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x8000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[477]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x10000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[478]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x20000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__add2 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2))) {
        ++(vlSymsp->__Vcoverage[479]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x40000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if (((vlSelfRef.eid_ctrl__DOT__add2 ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[480]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__add2 = 
            ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__add2) 
             | (0x80000000U & vlSelfRef.eid_ctrl__DOT__add2));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[321]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[322]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[323]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[324]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[325]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[326]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[327]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[328]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[329]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[330]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[331]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[332]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[333]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[334]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[335]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[336]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[337]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[338]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[339]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[340]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[341]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[342]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[343]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[344]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[345]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[346]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[347]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[348]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[349]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[350]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_alpha 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha))) {
        ++(vlSymsp->__Vcoverage[351]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_alpha ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[352]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_alpha) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_alpha));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[353]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[354]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[355]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[356]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[357]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[358]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[359]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[360]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[361]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[362]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[363]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[364]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[365]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[366]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[367]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[368]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[369]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[370]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[371]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[372]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[373]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[374]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[375]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[376]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[377]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[378]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[379]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[380]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[381]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[382]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_beta 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta))) {
        ++(vlSymsp->__Vcoverage[383]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_beta ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[384]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_beta) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_beta));
    }
    if ((1U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[385]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffeU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (1U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((2U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[386]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffdU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (2U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((4U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[387]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffffbU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (4U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((8U & (vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[388]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffff7U & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (8U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[389]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffefU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[390]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffdfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[391]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffffbfU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                  ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[392]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffff7fU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[393]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffeffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[394]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffdffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[395]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffffbffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                   ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[396]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffff7ffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[397]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffefffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[398]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffdfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[399]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffffbfffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                    ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[400]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffff7fffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[401]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffeffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[402]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffdffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[403]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfffbffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x80000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                     ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[404]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfff7ffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x100000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[405]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffefffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x100000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x200000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[406]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffdfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x200000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x400000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[407]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xffbfffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x400000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x800000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                      ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[408]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xff7fffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x800000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x1000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[409]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfeffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x1000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x2000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[410]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfdffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x2000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x4000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[411]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xfbffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x4000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x8000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                       ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[412]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xf7ffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x8000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x10000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[413]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xefffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x10000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x20000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[414]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xdfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x20000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if ((0x40000000U & (vlSelfRef.eid_ctrl__DOT__m_gamma 
                        ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma))) {
        ++(vlSymsp->__Vcoverage[415]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0xbfffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x40000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
    if (((vlSelfRef.eid_ctrl__DOT__m_gamma ^ vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
         >> 0x1fU)) {
        ++(vlSymsp->__Vcoverage[416]);
        vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma 
            = ((0x7fffffffU & vlSelfRef.eid_ctrl__DOT____Vtogcov__m_gamma) 
               | (0x80000000U & vlSelfRef.eid_ctrl__DOT__m_gamma));
    }
}

VL_ATTR_COLD void Veid_ctrl___024root___configure_coverage(Veid_ctrl___024root* vlSelf, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___configure_coverage\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    (void)first;  // Prevent unused variable warning
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[0]), first, "eid_ctrl.v", 12, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "clk", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[1]), first, "eid_ctrl.v", 13, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "rst_n", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[2]), first, "eid_ctrl.v", 16, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awaddr[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[3]), first, "eid_ctrl.v", 16, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awaddr[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[4]), first, "eid_ctrl.v", 16, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awaddr[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[5]), first, "eid_ctrl.v", 16, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awaddr[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[6]), first, "eid_ctrl.v", 17, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awvalid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[7]), first, "eid_ctrl.v", 18, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_awready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[8]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[9]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[10]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[11]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[12]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[13]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[14]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[15]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[16]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[17]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[18]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[19]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[20]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[21]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[22]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[23]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[24]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[25]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[26]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[27]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[28]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[29]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[30]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[31]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[32]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[33]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[34]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[35]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[36]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[37]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[38]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[39]), first, "eid_ctrl.v", 19, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wdata[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[40]), first, "eid_ctrl.v", 20, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wvalid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[7]), first, "eid_ctrl.v", 21, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_wready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[41]), first, "eid_ctrl.v", 24, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_araddr[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[42]), first, "eid_ctrl.v", 24, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_araddr[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[43]), first, "eid_ctrl.v", 24, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_araddr[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[44]), first, "eid_ctrl.v", 24, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_araddr[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[45]), first, "eid_ctrl.v", 25, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_arvalid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[7]), first, "eid_ctrl.v", 26, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_arready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 27, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rdata[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[46]), first, "eid_ctrl.v", 28, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rvalid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[47]), first, "eid_ctrl.v", 29, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "s_axi_rready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[48]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[49]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[50]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[51]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[52]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[53]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[54]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[55]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[56]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[57]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[58]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[59]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[60]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[61]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[62]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[63]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[64]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[65]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[66]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[67]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[68]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[69]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[70]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[71]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[72]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[73]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[74]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[75]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[76]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[77]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[78]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[79]), first, "eid_ctrl.v", 32, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_h[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[80]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[81]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[82]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[83]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[84]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[85]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[86]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[87]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[88]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[89]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[90]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[91]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[92]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[93]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[94]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[95]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[96]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[97]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[98]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[99]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[100]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[101]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[102]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[103]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[104]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[105]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[106]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[107]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[108]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[109]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[110]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[111]), first, "eid_ctrl.v", 33, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_f[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[112]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[113]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[114]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[115]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[116]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[117]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[118]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[119]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[120]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[121]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[122]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[123]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[124]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[125]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[126]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[127]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[128]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[129]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[130]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[131]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[132]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[133]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[134]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[135]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[136]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[137]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[138]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[139]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[140]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[141]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[142]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[143]), first, "eid_ctrl.v", 34, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_o[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[144]), first, "eid_ctrl.v", 35, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_valid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[7]), first, "eid_ctrl.v", 36, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "din_ready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[145]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[146]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[147]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[148]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[149]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[150]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[151]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[152]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[153]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[154]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[155]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[156]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[157]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[158]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[159]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[160]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[161]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[162]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[163]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[164]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[165]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[166]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[167]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[168]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[169]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[170]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[171]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[172]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[173]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[174]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[175]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[176]), first, "eid_ctrl.v", 39, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_dhdt[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[177]), first, "eid_ctrl.v", 40, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_alarm", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[178]), first, "eid_ctrl.v", 41, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_valid", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[179]), first, "eid_ctrl.v", 42, 33, ".eid_ctrl", "v_toggle/eid_ctrl", "dout_ready", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[180]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[181]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[182]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[183]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[184]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[185]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[186]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[187]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[188]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[189]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[190]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[191]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[192]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[193]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[194]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[195]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[196]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[197]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[198]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[199]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[200]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[201]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[202]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[203]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[204]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[205]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[206]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[207]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[208]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[209]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[210]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[211]), first, "eid_ctrl.v", 48, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "alpha[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[212]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[213]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[214]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[215]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[216]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[217]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[218]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[219]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[220]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[221]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[222]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[223]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[224]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[225]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[226]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[227]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[228]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[229]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[230]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[231]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[232]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[233]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[234]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[235]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[236]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[237]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[238]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[239]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[240]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[241]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[242]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[243]), first, "eid_ctrl.v", 48, 32, ".eid_ctrl", "v_toggle/eid_ctrl", "beta[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[244]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[245]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[246]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[247]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[248]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[249]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[250]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[251]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[252]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[253]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[254]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[255]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[256]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[257]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[258]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[259]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[260]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[261]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[262]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[263]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[264]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[265]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[266]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[267]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[268]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[269]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[270]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[271]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[272]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[273]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[274]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[275]), first, "eid_ctrl.v", 48, 38, ".eid_ctrl", "v_toggle/eid_ctrl", "gamma[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[276]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[277]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[278]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[279]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[280]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[281]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[282]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[283]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[284]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[285]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[286]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[287]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[288]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[289]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[290]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[291]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[292]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[293]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[294]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[295]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[296]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[297]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[298]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[299]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[300]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[301]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[302]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[303]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[304]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[305]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[306]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[307]), first, "eid_ctrl.v", 48, 45, ".eid_ctrl", "v_toggle/eid_ctrl", "delta[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[308]), first, "eid_ctrl.v", 67, 21, ".eid_ctrl", "v_line/eid_ctrl", "case", "67");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[309]), first, "eid_ctrl.v", 68, 21, ".eid_ctrl", "v_line/eid_ctrl", "case", "68");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[310]), first, "eid_ctrl.v", 69, 21, ".eid_ctrl", "v_line/eid_ctrl", "case", "69");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[311]), first, "eid_ctrl.v", 70, 21, ".eid_ctrl", "v_line/eid_ctrl", "case", "70");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[312]), first, "eid_ctrl.v", 65, 14, ".eid_ctrl", "v_branch/eid_ctrl", "if", "65-66");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[313]), first, "eid_ctrl.v", 65, 15, ".eid_ctrl", "v_branch/eid_ctrl", "else", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[314]), first, "eid_ctrl.v", 65, 32, ".eid_ctrl", "v_expr/eid_ctrl", "(s_axi_awvalid==1 && s_axi_wvalid==1) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[315]), first, "eid_ctrl.v", 65, 32, ".eid_ctrl", "v_expr/eid_ctrl", "(s_axi_wvalid==0) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[316]), first, "eid_ctrl.v", 65, 32, ".eid_ctrl", "v_expr/eid_ctrl", "(s_axi_awvalid==0) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[317]), first, "eid_ctrl.v", 59, 9, ".eid_ctrl", "v_line/eid_ctrl", "elsif", "59-63");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[318]), first, "eid_ctrl.v", 59, 13, ".eid_ctrl", "v_expr/eid_ctrl", "(rst_n==0) => 1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[319]), first, "eid_ctrl.v", 59, 13, ".eid_ctrl", "v_expr/eid_ctrl", "(rst_n==1) => 0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[320]), first, "eid_ctrl.v", 58, 5, ".eid_ctrl", "v_line/eid_ctrl", "block", "58");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[321]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[322]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[323]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[324]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[325]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[326]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[327]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[328]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[329]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[330]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[331]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[332]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[333]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[334]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[335]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[336]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[337]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[338]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[339]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[340]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[341]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[342]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[343]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[344]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[345]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[346]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[347]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[348]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[349]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[350]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[351]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[352]), first, "eid_ctrl.v", 78, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "m_alpha[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[353]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[354]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[355]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[356]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[357]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[358]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[359]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[360]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[361]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[362]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[363]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[364]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[365]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[366]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[367]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[368]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[369]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[370]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[371]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[372]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[373]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[374]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[375]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[376]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[377]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[378]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[379]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[380]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[381]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[382]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[383]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[384]), first, "eid_ctrl.v", 78, 34, ".eid_ctrl", "v_toggle/eid_ctrl", "m_beta[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[385]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[386]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[387]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[388]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[389]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[390]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[391]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[392]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[393]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[394]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[395]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[396]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[397]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[398]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[399]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[400]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[401]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[402]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[403]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[404]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[405]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[406]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[407]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[408]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[409]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[410]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[411]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[412]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[413]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[414]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[415]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[416]), first, "eid_ctrl.v", 78, 42, ".eid_ctrl", "v_toggle/eid_ctrl", "m_gamma[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[417]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[418]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[419]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[420]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[421]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[422]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[423]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[424]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[425]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[426]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[427]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[428]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[429]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[430]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[431]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[432]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[433]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[434]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[435]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[436]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[437]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[438]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[439]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[440]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[441]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[442]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[443]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[444]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[445]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[446]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[447]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[448]), first, "eid_ctrl.v", 79, 25, ".eid_ctrl", "v_toggle/eid_ctrl", "add1[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[449]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[450]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[451]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[452]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[453]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[454]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[455]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[456]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[457]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[458]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[459]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[460]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[461]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[462]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[463]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[464]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[465]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[466]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[467]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[468]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[469]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[470]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[471]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[472]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[473]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[474]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[475]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[476]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[477]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[478]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[479]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[480]), first, "eid_ctrl.v", 79, 31, ".eid_ctrl", "v_toggle/eid_ctrl", "add2[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[145]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[0]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[146]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[1]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[147]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[2]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[148]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[3]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[149]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[4]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[150]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[5]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[151]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[6]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[152]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[7]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[153]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[8]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[154]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[9]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[155]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[10]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[156]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[11]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[157]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[12]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[158]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[13]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[159]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[14]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[160]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[15]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[161]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[16]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[162]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[17]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[163]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[18]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[164]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[19]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[165]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[20]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[166]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[21]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[167]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[22]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[168]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[23]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[169]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[24]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[170]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[25]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[171]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[26]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[172]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[27]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[173]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[28]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[174]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[29]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[175]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[30]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[176]), first, "eid_ctrl.v", 79, 37, ".eid_ctrl", "v_toggle/eid_ctrl", "dhdt_q32[31]", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[481]), first, "eid_ctrl.v", 90, 9, ".eid_ctrl", "v_toggle/eid_ctrl", "v0", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[482]), first, "eid_ctrl.v", 90, 13, ".eid_ctrl", "v_toggle/eid_ctrl", "v1", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[483]), first, "eid_ctrl.v", 90, 17, ".eid_ctrl", "v_toggle/eid_ctrl", "v2", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[484]), first, "eid_ctrl.v", 91, 5, ".eid_ctrl", "v_line/eid_ctrl", "block", "91-94");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[485]), first, "eid_ctrl.v", 102, 9, ".eid_ctrl", "v_toggle/eid_ctrl", "alarm_r", "");
    vlSelf->__vlCoverInsert(&(vlSymsp->__Vcoverage[486]), first, "eid_ctrl.v", 103, 5, ".eid_ctrl", "v_line/eid_ctrl", "block", "103");
}
