// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Veid_ctrl.h for the primary calling header

#ifndef VERILATED_VEID_CTRL___024ROOT_H_
#define VERILATED_VEID_CTRL___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_cov.h"


class Veid_ctrl__Syms;

class alignas(VL_CACHE_LINE_BYTES) Veid_ctrl___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(rst_n,0,0);
        VL_IN8(s_axi_awaddr,3,0);
        VL_IN8(s_axi_awvalid,0,0);
        VL_OUT8(s_axi_awready,0,0);
        VL_IN8(s_axi_wvalid,0,0);
        VL_OUT8(s_axi_wready,0,0);
        VL_IN8(s_axi_araddr,3,0);
        VL_IN8(s_axi_arvalid,0,0);
        VL_OUT8(s_axi_arready,0,0);
        VL_OUT8(s_axi_rvalid,0,0);
        VL_IN8(s_axi_rready,0,0);
        VL_IN8(din_valid,0,0);
        VL_OUT8(din_ready,0,0);
        VL_OUT8(dout_alarm,0,0);
        VL_OUT8(dout_valid,0,0);
        VL_IN8(dout_ready,0,0);
        CData/*0:0*/ eid_ctrl__DOT__v0;
        CData/*0:0*/ eid_ctrl__DOT__v1;
        CData/*0:0*/ eid_ctrl__DOT__v2;
        CData/*0:0*/ eid_ctrl__DOT__alarm_r;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__clk;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__rst_n;
        CData/*3:0*/ eid_ctrl__DOT____Vtogcov__s_axi_awaddr;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__s_axi_awvalid;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__s_axi_awready;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__s_axi_wvalid;
        CData/*3:0*/ eid_ctrl__DOT____Vtogcov__s_axi_araddr;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__s_axi_arvalid;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__s_axi_rready;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__din_valid;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__dout_alarm;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__dout_valid;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__dout_ready;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__v0;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__v1;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__v2;
        CData/*0:0*/ eid_ctrl__DOT____Vtogcov__alarm_r;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VicoFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
        CData/*0:0*/ __Vtrigprevexpr___TOP__rst_n__0;
        CData/*0:0*/ __VactContinue;
        VL_IN(s_axi_wdata,31,0);
        VL_OUT(s_axi_rdata,31,0);
        VL_IN(din_h,31,0);
        VL_IN(din_f,31,0);
        VL_IN(din_o,31,0);
        VL_OUT(dout_dhdt,31,0);
        IData/*31:0*/ eid_ctrl__DOT__alpha;
        IData/*31:0*/ eid_ctrl__DOT__beta;
        IData/*31:0*/ eid_ctrl__DOT__gamma;
        IData/*31:0*/ eid_ctrl__DOT__delta;
        IData/*31:0*/ eid_ctrl__DOT__m_alpha;
        IData/*31:0*/ eid_ctrl__DOT__m_beta;
        IData/*31:0*/ eid_ctrl__DOT__m_gamma;
        IData/*31:0*/ eid_ctrl__DOT__add1;
        IData/*31:0*/ eid_ctrl__DOT__add2;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__s_axi_wdata;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__s_axi_rdata;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__din_h;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__din_f;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__din_o;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__dout_dhdt;
    };
    struct {
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__alpha;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__beta;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__gamma;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__delta;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__m_alpha;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__m_beta;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__m_gamma;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__add1;
        IData/*31:0*/ eid_ctrl__DOT____Vtogcov__add2;
        IData/*31:0*/ __VactIterCount;
        QData/*32:0*/ eid_ctrl__DOT__add_s1__DOT__s;
        QData/*32:0*/ eid_ctrl__DOT__add_s2a__DOT__s;
        QData/*32:0*/ eid_ctrl__DOT__add_s2b__DOT__s;
        VlUnpacked<CData/*0:0*/, 3> __Vm_traceActivity;
    };
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Veid_ctrl__Syms* const vlSymsp;

    // CONSTRUCTORS
    Veid_ctrl___024root(Veid_ctrl__Syms* symsp, const char* v__name);
    ~Veid_ctrl___024root();
    VL_UNCOPYABLE(Veid_ctrl___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    void __vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
        const char* hierp, const char* pagep, const char* commentp, const char* linescovp);
};


#endif  // guard
