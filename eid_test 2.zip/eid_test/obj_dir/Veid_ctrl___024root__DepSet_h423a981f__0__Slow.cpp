// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Veid_ctrl.h for the primary calling header

#include "Veid_ctrl__pch.h"
#include "Veid_ctrl___024root.h"

VL_ATTR_COLD void Veid_ctrl___024root___eval_static__TOP(Veid_ctrl___024root* vlSelf);
VL_ATTR_COLD void Veid_ctrl___024root____Vm_traceActivitySetAll(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD void Veid_ctrl___024root___eval_static(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_static\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Veid_ctrl___024root___eval_static__TOP(vlSelf);
    Veid_ctrl___024root____Vm_traceActivitySetAll(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP__clk__0 = vlSelfRef.clk;
    vlSelfRef.__Vtrigprevexpr___TOP__rst_n__0 = vlSelfRef.rst_n;
}

VL_ATTR_COLD void Veid_ctrl___024root___eval_static__TOP(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_static__TOP\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.eid_ctrl__DOT__add_s1__DOT__s = (0x1ffffffffULL 
                                               & (VL_EXTENDS_QI(33,32, vlSelfRef.eid_ctrl__DOT__m_alpha) 
                                                  + 
                                                  VL_EXTENDS_QI(33,32, vlSelfRef.eid_ctrl__DOT__m_beta)));
    vlSelfRef.eid_ctrl__DOT__add_s2a__DOT__s = (0x1ffffffffULL 
                                                & (VL_EXTENDS_QI(33,32, vlSelfRef.eid_ctrl__DOT__add1) 
                                                   + 
                                                   VL_EXTENDS_QI(33,32, 
                                                                 (- vlSelfRef.eid_ctrl__DOT__m_gamma))));
    vlSelfRef.eid_ctrl__DOT__add_s2b__DOT__s = (0x1ffffffffULL 
                                                & (VL_EXTENDS_QI(33,32, vlSelfRef.eid_ctrl__DOT__add2) 
                                                   + 
                                                   VL_EXTENDS_QI(33,32, vlSelfRef.eid_ctrl__DOT__delta)));
}

VL_ATTR_COLD void Veid_ctrl___024root___eval_initial__TOP(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD void Veid_ctrl___024root___eval_initial(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_initial\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Veid_ctrl___024root___eval_initial__TOP(vlSelf);
}

VL_ATTR_COLD void Veid_ctrl___024root___eval_final(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_final\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__stl(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Veid_ctrl___024root___eval_phase__stl(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD void Veid_ctrl___024root___eval_settle(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_settle\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY(((0x64U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Veid_ctrl___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("eid_ctrl.v", 8, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Veid_ctrl___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__stl(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___dump_triggers__stl\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Veid_ctrl___024root___stl_sequent__TOP__0(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD void Veid_ctrl___024root___eval_stl(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_stl\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        Veid_ctrl___024root___stl_sequent__TOP__0(vlSelf);
        Veid_ctrl___024root____Vm_traceActivitySetAll(vlSelf);
    }
}

VL_ATTR_COLD void Veid_ctrl___024root___eval_triggers__stl(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD bool Veid_ctrl___024root___eval_phase__stl(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___eval_phase__stl\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Veid_ctrl___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        Veid_ctrl___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__ico(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___dump_triggers__ico\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VicoTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__act(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___dump_triggers__act\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(negedge rst_n)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Veid_ctrl___024root___dump_triggers__nba(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___dump_triggers__nba\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(negedge rst_n)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Veid_ctrl___024root____Vm_traceActivitySetAll(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root____Vm_traceActivitySetAll\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[0U] = 1U;
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

VL_ATTR_COLD void Veid_ctrl___024root___ctor_var_reset(Veid_ctrl___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root___ctor_var_reset\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->rst_n = VL_RAND_RESET_I(1);
    vlSelf->s_axi_awaddr = VL_RAND_RESET_I(4);
    vlSelf->s_axi_awvalid = VL_RAND_RESET_I(1);
    vlSelf->s_axi_awready = VL_RAND_RESET_I(1);
    vlSelf->s_axi_wdata = VL_RAND_RESET_I(32);
    vlSelf->s_axi_wvalid = VL_RAND_RESET_I(1);
    vlSelf->s_axi_wready = VL_RAND_RESET_I(1);
    vlSelf->s_axi_araddr = VL_RAND_RESET_I(4);
    vlSelf->s_axi_arvalid = VL_RAND_RESET_I(1);
    vlSelf->s_axi_arready = VL_RAND_RESET_I(1);
    vlSelf->s_axi_rdata = VL_RAND_RESET_I(32);
    vlSelf->s_axi_rvalid = VL_RAND_RESET_I(1);
    vlSelf->s_axi_rready = VL_RAND_RESET_I(1);
    vlSelf->din_h = VL_RAND_RESET_I(32);
    vlSelf->din_f = VL_RAND_RESET_I(32);
    vlSelf->din_o = VL_RAND_RESET_I(32);
    vlSelf->din_valid = VL_RAND_RESET_I(1);
    vlSelf->din_ready = VL_RAND_RESET_I(1);
    vlSelf->dout_dhdt = VL_RAND_RESET_I(32);
    vlSelf->dout_alarm = VL_RAND_RESET_I(1);
    vlSelf->dout_valid = VL_RAND_RESET_I(1);
    vlSelf->dout_ready = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT__alpha = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__beta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__gamma = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__delta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__m_alpha = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__m_beta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__m_gamma = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__add1 = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__add2 = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT__v0 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT__v1 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT__v2 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT__alarm_r = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__clk = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__rst_n = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_awaddr = VL_RAND_RESET_I(4);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_awvalid = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_awready = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_wdata = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_wvalid = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_araddr = VL_RAND_RESET_I(4);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_arvalid = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_rdata = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__s_axi_rready = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__din_h = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__din_f = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__din_o = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__din_valid = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__dout_dhdt = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__dout_alarm = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__dout_valid = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__dout_ready = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__alpha = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__beta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__gamma = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__delta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__m_alpha = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__m_beta = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__m_gamma = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__add1 = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__add2 = VL_RAND_RESET_I(32);
    vlSelf->eid_ctrl__DOT____Vtogcov__v0 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__v1 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__v2 = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT____Vtogcov__alarm_r = VL_RAND_RESET_I(1);
    vlSelf->eid_ctrl__DOT__add_s1__DOT__s = VL_RAND_RESET_Q(33);
    vlSelf->eid_ctrl__DOT__add_s2a__DOT__s = VL_RAND_RESET_Q(33);
    vlSelf->eid_ctrl__DOT__add_s2b__DOT__s = VL_RAND_RESET_Q(33);
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__rst_n__0 = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 3; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}
