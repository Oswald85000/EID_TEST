// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Veid_ctrl__pch.h"
#include "verilated_vcd_c.h"

//============================================================
// Constructors

Veid_ctrl::Veid_ctrl(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Veid_ctrl__Syms(contextp(), _vcname__, this)}
    , clk{vlSymsp->TOP.clk}
    , rst_n{vlSymsp->TOP.rst_n}
    , s_axi_awaddr{vlSymsp->TOP.s_axi_awaddr}
    , s_axi_awvalid{vlSymsp->TOP.s_axi_awvalid}
    , s_axi_awready{vlSymsp->TOP.s_axi_awready}
    , s_axi_wvalid{vlSymsp->TOP.s_axi_wvalid}
    , s_axi_wready{vlSymsp->TOP.s_axi_wready}
    , s_axi_araddr{vlSymsp->TOP.s_axi_araddr}
    , s_axi_arvalid{vlSymsp->TOP.s_axi_arvalid}
    , s_axi_arready{vlSymsp->TOP.s_axi_arready}
    , s_axi_rvalid{vlSymsp->TOP.s_axi_rvalid}
    , s_axi_rready{vlSymsp->TOP.s_axi_rready}
    , din_valid{vlSymsp->TOP.din_valid}
    , din_ready{vlSymsp->TOP.din_ready}
    , dout_alarm{vlSymsp->TOP.dout_alarm}
    , dout_valid{vlSymsp->TOP.dout_valid}
    , dout_ready{vlSymsp->TOP.dout_ready}
    , s_axi_wdata{vlSymsp->TOP.s_axi_wdata}
    , s_axi_rdata{vlSymsp->TOP.s_axi_rdata}
    , din_h{vlSymsp->TOP.din_h}
    , din_f{vlSymsp->TOP.din_f}
    , din_o{vlSymsp->TOP.din_o}
    , dout_dhdt{vlSymsp->TOP.dout_dhdt}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
    contextp()->traceBaseModelCbAdd(
        [this](VerilatedTraceBaseC* tfp, int levels, int options) { traceBaseModel(tfp, levels, options); });
}

Veid_ctrl::Veid_ctrl(const char* _vcname__)
    : Veid_ctrl(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Veid_ctrl::~Veid_ctrl() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Veid_ctrl___024root___eval_debug_assertions(Veid_ctrl___024root* vlSelf);
#endif  // VL_DEBUG
void Veid_ctrl___024root___eval_static(Veid_ctrl___024root* vlSelf);
void Veid_ctrl___024root___eval_initial(Veid_ctrl___024root* vlSelf);
void Veid_ctrl___024root___eval_settle(Veid_ctrl___024root* vlSelf);
void Veid_ctrl___024root___eval(Veid_ctrl___024root* vlSelf);

void Veid_ctrl::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Veid_ctrl::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Veid_ctrl___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_activity = true;
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Veid_ctrl___024root___eval_static(&(vlSymsp->TOP));
        Veid_ctrl___024root___eval_initial(&(vlSymsp->TOP));
        Veid_ctrl___024root___eval_settle(&(vlSymsp->TOP));
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Veid_ctrl___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Veid_ctrl::eventsPending() { return false; }

uint64_t Veid_ctrl::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Veid_ctrl::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Veid_ctrl___024root___eval_final(Veid_ctrl___024root* vlSelf);

VL_ATTR_COLD void Veid_ctrl::final() {
    Veid_ctrl___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Veid_ctrl::hierName() const { return vlSymsp->name(); }
const char* Veid_ctrl::modelName() const { return "Veid_ctrl"; }
unsigned Veid_ctrl::threads() const { return 1; }
void Veid_ctrl::prepareClone() const { contextp()->prepareClone(); }
void Veid_ctrl::atClone() const {
    contextp()->threadPoolpOnClone();
}
std::unique_ptr<VerilatedTraceConfig> Veid_ctrl::traceConfig() const {
    return std::unique_ptr<VerilatedTraceConfig>{new VerilatedTraceConfig{false, false, false}};
};

//============================================================
// Trace configuration

void Veid_ctrl___024root__trace_decl_types(VerilatedVcd* tracep);

void Veid_ctrl___024root__trace_init_top(Veid_ctrl___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD static void trace_init(void* voidSelf, VerilatedVcd* tracep, uint32_t code) {
    // Callback from tracep->open()
    Veid_ctrl___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Veid_ctrl___024root*>(voidSelf);
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (!vlSymsp->_vm_contextp__->calcUnusedSigs()) {
        VL_FATAL_MT(__FILE__, __LINE__, __FILE__,
            "Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vlSymsp->__Vm_baseCode = code;
    tracep->pushPrefix(std::string{vlSymsp->name()}, VerilatedTracePrefixType::SCOPE_MODULE);
    Veid_ctrl___024root__trace_decl_types(tracep);
    Veid_ctrl___024root__trace_init_top(vlSelf, tracep);
    tracep->popPrefix();
}

VL_ATTR_COLD void Veid_ctrl___024root__trace_register(Veid_ctrl___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Veid_ctrl::traceBaseModel(VerilatedTraceBaseC* tfp, int levels, int options) {
    (void)levels; (void)options;
    VerilatedVcdC* const stfp = dynamic_cast<VerilatedVcdC*>(tfp);
    if (VL_UNLIKELY(!stfp)) {
        vl_fatal(__FILE__, __LINE__, __FILE__,"'Veid_ctrl::trace()' called on non-VerilatedVcdC object;"
            " use --trace-fst with VerilatedFst object, and --trace-vcd with VerilatedVcd object");
    }
    stfp->spTrace()->addModel(this);
    stfp->spTrace()->addInitCb(&trace_init, &(vlSymsp->TOP));
    Veid_ctrl___024root__trace_register(&(vlSymsp->TOP), stfp->spTrace());
}
