// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Veid_ctrl__Syms.h"


void Veid_ctrl___024root__trace_chg_0_sub_0(Veid_ctrl___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Veid_ctrl___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root__trace_chg_0\n"); );
    // Init
    Veid_ctrl___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Veid_ctrl___024root*>(voidSelf);
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Veid_ctrl___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Veid_ctrl___024root__trace_chg_0_sub_0(Veid_ctrl___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root__trace_chg_0_sub_0\n"); );
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[0U]))) {
        bufp->chgIData(oldp+0,(vlSelfRef.eid_ctrl__DOT__add1),32);
        bufp->chgIData(oldp+1,(vlSelfRef.eid_ctrl__DOT__add2),32);
        bufp->chgQData(oldp+2,(vlSelfRef.eid_ctrl__DOT__add_s1__DOT__s),33);
        bufp->chgQData(oldp+4,(vlSelfRef.eid_ctrl__DOT__add_s2a__DOT__s),33);
        bufp->chgQData(oldp+6,(vlSelfRef.eid_ctrl__DOT__add_s2b__DOT__s),33);
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[1U]))) {
        bufp->chgBit(oldp+8,(vlSelfRef.eid_ctrl__DOT__v0));
        bufp->chgBit(oldp+9,(vlSelfRef.eid_ctrl__DOT__v1));
        bufp->chgBit(oldp+10,(vlSelfRef.eid_ctrl__DOT__v2));
        bufp->chgBit(oldp+11,(vlSelfRef.eid_ctrl__DOT__alarm_r));
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[2U]))) {
        bufp->chgIData(oldp+12,(vlSelfRef.eid_ctrl__DOT__alpha),32);
        bufp->chgIData(oldp+13,(vlSelfRef.eid_ctrl__DOT__beta),32);
        bufp->chgIData(oldp+14,(vlSelfRef.eid_ctrl__DOT__gamma),32);
        bufp->chgIData(oldp+15,(vlSelfRef.eid_ctrl__DOT__delta),32);
        bufp->chgIData(oldp+16,((- vlSelfRef.eid_ctrl__DOT__alpha)),32);
    }
    bufp->chgBit(oldp+17,(vlSelfRef.clk));
    bufp->chgBit(oldp+18,(vlSelfRef.rst_n));
    bufp->chgCData(oldp+19,(vlSelfRef.s_axi_awaddr),4);
    bufp->chgBit(oldp+20,(vlSelfRef.s_axi_awvalid));
    bufp->chgBit(oldp+21,(vlSelfRef.s_axi_awready));
    bufp->chgIData(oldp+22,(vlSelfRef.s_axi_wdata),32);
    bufp->chgBit(oldp+23,(vlSelfRef.s_axi_wvalid));
    bufp->chgBit(oldp+24,(vlSelfRef.s_axi_wready));
    bufp->chgCData(oldp+25,(vlSelfRef.s_axi_araddr),4);
    bufp->chgBit(oldp+26,(vlSelfRef.s_axi_arvalid));
    bufp->chgBit(oldp+27,(vlSelfRef.s_axi_arready));
    bufp->chgIData(oldp+28,(vlSelfRef.s_axi_rdata),32);
    bufp->chgBit(oldp+29,(vlSelfRef.s_axi_rvalid));
    bufp->chgBit(oldp+30,(vlSelfRef.s_axi_rready));
    bufp->chgIData(oldp+31,(vlSelfRef.din_h),32);
    bufp->chgIData(oldp+32,(vlSelfRef.din_f),32);
    bufp->chgIData(oldp+33,(vlSelfRef.din_o),32);
    bufp->chgBit(oldp+34,(vlSelfRef.din_valid));
    bufp->chgBit(oldp+35,(vlSelfRef.din_ready));
    bufp->chgIData(oldp+36,(vlSelfRef.dout_dhdt),32);
    bufp->chgBit(oldp+37,(vlSelfRef.dout_alarm));
    bufp->chgBit(oldp+38,(vlSelfRef.dout_valid));
    bufp->chgBit(oldp+39,(vlSelfRef.dout_ready));
    bufp->chgIData(oldp+40,(vlSelfRef.eid_ctrl__DOT__m_alpha),32);
    bufp->chgIData(oldp+41,(vlSelfRef.eid_ctrl__DOT__m_beta),32);
    bufp->chgIData(oldp+42,(vlSelfRef.eid_ctrl__DOT__m_gamma),32);
    bufp->chgIData(oldp+43,((- vlSelfRef.eid_ctrl__DOT__m_gamma)),32);
    bufp->chgQData(oldp+44,(VL_MULS_QQQ(64, VL_EXTENDS_QI(64,32, 
                                                          (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                        VL_EXTENDS_QI(64,32, vlSelfRef.din_h))),64);
    bufp->chgIData(oldp+46,((IData)((VL_MULS_QQQ(64, 
                                                 VL_EXTENDS_QI(64,32, 
                                                               (- vlSelfRef.eid_ctrl__DOT__alpha)), 
                                                 VL_EXTENDS_QI(64,32, vlSelfRef.din_h)) 
                                     >> 0x10U))),32);
    bufp->chgQData(oldp+47,(VL_MULS_QQQ(64, VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                        VL_EXTENDS_QI(64,32, vlSelfRef.din_f))),64);
    bufp->chgIData(oldp+49,((IData)((VL_MULS_QQQ(64, 
                                                 VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__beta), 
                                                 VL_EXTENDS_QI(64,32, vlSelfRef.din_f)) 
                                     >> 0x10U))),32);
    bufp->chgQData(oldp+50,(VL_MULS_QQQ(64, VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                        VL_EXTENDS_QI(64,32, vlSelfRef.din_o))),64);
    bufp->chgIData(oldp+52,((IData)((VL_MULS_QQQ(64, 
                                                 VL_EXTENDS_QI(64,32, vlSelfRef.eid_ctrl__DOT__gamma), 
                                                 VL_EXTENDS_QI(64,32, vlSelfRef.din_o)) 
                                     >> 0x10U))),32);
}

void Veid_ctrl___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Veid_ctrl___024root__trace_cleanup\n"); );
    // Init
    Veid_ctrl___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Veid_ctrl___024root*>(voidSelf);
    Veid_ctrl__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
}
